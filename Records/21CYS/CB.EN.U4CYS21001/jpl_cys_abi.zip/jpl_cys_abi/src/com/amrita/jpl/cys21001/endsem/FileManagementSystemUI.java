package com.amrita.jpl.cys21001.endsem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**@author Abinesh G (cys21001)
 * It is file management system
 */
abstract class File {
    private String fileName;
    private long fileSize;

    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public abstract String getFileType();

    public abstract String getFileDetails();
}

class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getFileType() {
        return "com.amrita.jpl.cys21001.endsem.Document";
    }

    public String getFileDetails() {
        return "Type: " + getDocumentType() + ", Size: " + getFileSize();
    }
}

class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public String getFileType() {
        return "com.amrita.jpl.cys21001.endsem.Image";
    }

    public String getFileDetails() {
        return "Resolution: " + getResolution() + ", Size: " + getFileSize();
    }
}

class Video extends File {
    private String duration;

    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getFileType() {
        return "com.amrita.jpl.cys21001.endsem.Video";
    }

    public String getFileDetails() {
        return "Duration: " + getDuration() + ", Size: " + getFileSize();
    }
}

interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void saveToFile();

    void loadFromFile();

    ArrayList<File> getFiles();
}

class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            File file = files.get(i);
            if (file.getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    public void saveToFile() {
        // Save file details to a text file
    }

    public void loadFromFile() {
        // Load file details from a text file
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}

public class FileManagementSystemUI extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField nameField;
    private JTextField sizeField;
    private JButton addButton;
    private JButton deleteButton;


    private FileManager fileManager;

    private JComboBox<String> fileTypeComboBox;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("com.amrita.jpl.cys21001.endsem.File Name");
        tableModel.addColumn("Type");
        tableModel.addColumn("Size");
        tableModel.addColumn("Details");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        nameField = new JTextField(10);
        sizeField = new JTextField(10);

        // Initialize the fileTypeComboBox
        List<String> fileTypes = Arrays.asList("com.amrita.jpl.cys21001.endsem.Document", "com.amrita.jpl.cys21001.endsem.Image", "com.amrita.jpl.cys21001.endsem.Video");
        fileTypeComboBox = new JComboBox<>(fileTypes.toArray(new String[0]));

        JPanel formPanel = new JPanel(new GridLayout(3, 2));
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Size:"));
        formPanel.add(sizeField);
        formPanel.add(new JLabel("Type:"));
        formPanel.add(fileTypeComboBox);

        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addFile();
            }
        });

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFile();
            }
        });



        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);


        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        setTitle("com.amrita.jpl.cys21001.endsem.File Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addFile() {
        String name = nameField.getText();
        String sizeText = sizeField.getText();
        String fileType = (String) fileTypeComboBox.getSelectedItem();

        long size;
        try {
            size = Long.parseLong(sizeText);
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid file size. Please enter a valid numeric value.");
            return;
        }

        File file;
        if (fileType.equals("com.amrita.jpl.cys21001.endsem.Document")) {
            String documentType = JOptionPane.showInputDialog(this, "Enter the document type:");
            file = new Document(name, size, documentType);
        } else if (fileType.equals("com.amrita.jpl.cys21001.endsem.Image")) {
            String resolution = JOptionPane.showInputDialog(this, "Enter the resolution:");
            file = new Image(name, size, resolution);
        } else {
            String duration = JOptionPane.showInputDialog(this, "Enter the duration:");
            file = new Video(name, size, duration);
        }

        fileManager.addFile(file);
        displayFiles();
        clearFormFields();
    }

    private void deleteFile() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            showErrorDialog("Please select a file to delete.");
            return;
        }

        String fileName = (String) table.getValueAt(selectedRow, 0);
        fileManager.deleteFile(fileName);
        displayFiles();
    }

    private void displayFiles() {
        clearTable();

        ArrayList<File> files = fileManager.getFiles();
        for (File file : files) {
            Object[] row = new Object[4];
            row[0] = file.getFileName();
            row[1] = file.getFileType();
            row[2] = file.getFileSize();
            row[3] = file.getFileDetails();
            tableModel.addRow(row);
        }
    }

    private void clearFormFields() {
        nameField.setText("");
        sizeField.setText("");
    }

    private void clearTable() {
        tableModel.setRowCount(0);
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}
