package com.amrita.jpl.cys21001.p2;

import com.amrita.jpl.cys21001.p2.QuizGame;
import com.amrita.jpl.cys21001.p2.QuizGameClient;
import com.amrita.jpl.cys21001.p2.QuizGameListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class QuizGameServer extends QuizGame {
    List<String> questions;
    List<QuizGameListener> listeners;
    List<String> answers;

    public QuizGameServer() {

        questions = new ArrayList<>();
        questions.add("Which college held C20 Summit?");
        questions.add("What is the class strength of cys 2nd year?");
        questions.add("Which professor is handling java for above class?");

        answers = new ArrayList<>();
        answers.add("Amrita");
        answers.add("86");
        answers.add("Ramaguru");

        listeners = new ArrayList<>();

    }

    @Override
    public void startGame() {
        listeners.add(new QuizGameClient(this));
        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked("Let the quiz game begin!");
        }
        askQuestion();
    }

    @Override
    public void askQuestion() {
        Random random = new Random();
        int index = random.nextInt(questions.size());
        String question = questions.get(index);

        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked(question);
        }
    }

    @Override
    public void evaluateAnswer(String answer) {
        boolean isCorrect = false;
        if (answer.equalsIgnoreCase(answers.get(0))) {
            isCorrect = true;
        }
        for (QuizGameListener listener : listeners) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }
}